package modelo;

import android.content.Context;
import android.content.SharedPreferences;
import android.widget.Toast;

import java.io.File;

public final class ManagerDiretoriosApp {

    public interface Resultado {
        void aoFinalizar(File pastaProjetos, boolean sucesso);
    }
    
    // Chave usada no SharedPreferences para saber se já rodamos o bootstrap
    private static final String PREFS_NOME  = "aml_ide_prefs";
    private static final String PREFS_BOOT  = "bootstrap_diretorios_ok";

    private ManagerDiretoriosApp() { }

    // ---------- Helpers ----------

    private static boolean jaInicializou(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS_NOME, Context.MODE_PRIVATE);
        return prefs.getBoolean(PREFS_BOOT, false);
    }

    private static void marcarComoInicializado(Context ctx) {
        SharedPreferences prefs = ctx.getSharedPreferences(PREFS_NOME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(PREFS_BOOT, true).apply();
    }
}
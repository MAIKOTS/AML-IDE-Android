package modelo;

import android.util.Log;

import java.io.File;

import ui.util.GerenciadorDeArquivos;

public class GerenciadorDeProjetos {

    private static final String TAG = "GerenciadorDeProjetos";

    private File pastaProjetoAtual;

    public boolean criarNovoProjeto(File pastaDestino, String nomeProjeto) {
        if (pastaDestino == null || nomeProjeto == null || nomeProjeto.isEmpty()) {
            Log.w(TAG, "Parâmetros inválidos em criarNovoProjeto");
            return false;
        }

        pastaProjetoAtual = new File(pastaDestino, nomeProjeto);

        if (pastaProjetoAtual.exists()) {
            if (!pastaProjetoAtual.isDirectory()) return false;
            // já existe — reaproveita
        } else if (!pastaProjetoAtual.mkdirs()) {
            Log.e(TAG, "Falha ao criar pasta do projeto: " + pastaProjetoAtual);
            return false;
        }

        // Subpastas padrão
        File pastaFonte    = new File(pastaProjetoAtual, "src");
        File pastaIncludes = new File(pastaProjetoAtual, "include");
        File pastaSaida    = new File(pastaProjetoAtual, "out");

        if (!garantirPasta(pastaFonte)
                || !garantirPasta(pastaIncludes)
                || !garantirPasta(pastaSaida)) {
            return false;
        }

        // Arquivo principal
        File arquivoPrincipal = new File(pastaFonte, "main.cpp");

        // Só cria se ainda não existir (não sobrescreve trabalho do usuário)
        if (arquivoPrincipal.exists()) {
            return true;
        }

        String codigoModeloAML =
                "// Mod AML para GTA San Andreas Android\n" +
                "#include <jni.h>\n\n" +
                "extern \"C\" {\n" +
                "    __attribute__((visibility(\"default\")))\n" +
                "    void AMLMain() {\n" +
                "        // Código de inicialização do seu mod aqui\n" +
                "    }\n" +
                "}\n";

        return GerenciadorDeArquivos.salvarArquivo(arquivoPrincipal, codigoModeloAML);
    }

    public boolean carregarProjetoExistente(File pastaExistente) {
        if (pastaExistente != null && pastaExistente.isDirectory()) {
            this.pastaProjetoAtual = pastaExistente;
            return true;
        }
        return false;
    }

    public File obterPastaProjetoAtual() {
        return pastaProjetoAtual;
    }

    // ---------- Helpers ----------

    private boolean garantirPasta(File pasta) {
        if (pasta.exists()) return pasta.isDirectory();
        if (!pasta.mkdirs()) {
            Log.e(TAG, "Falha ao criar: " + pasta.getAbsolutePath());
            return false;
        }
        return true;
    }
}
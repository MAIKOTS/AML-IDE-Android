package ui.componentes;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.HorizontalScrollView;

public class HorizontalScrollViewSeguro extends HorizontalScrollView {

    private float downX, downY;
    private final float limiarPx;
    private boolean interceptandoHorizontal = false;

    public HorizontalScrollViewSeguro(Context context) {
        this(context, null);
    }

    public HorizontalScrollViewSeguro(Context context, AttributeSet attrs) {
        super(context, attrs);
        setSmoothScrollingEnabled(true);
        limiarPx = 15 * context.getResources().getDisplayMetrics().density;
    }

    /**
     * Ignora a proibição do filho — queremos poder interceptar gestos horizontais.
     */
    @Override
    public void requestDisallowInterceptTouchEvent(boolean disallowIntercept) {
        // Intencionalmente vazio
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent ev) {
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = ev.getX();
                downY = ev.getY();
                interceptandoHorizontal = false;
                // Não intercepta o down
                return false;

            case MotionEvent.ACTION_MOVE:
                if (interceptandoHorizontal) return true;

                float dx = Math.abs(ev.getX() - downX);
                float dy = Math.abs(ev.getY() - downY);

                if (dx > limiarPx && dx > dy) {
                    // Gesto claramente horizontal → HSV assume
                    interceptandoHorizontal = true;
                    return true;
                }
                return false;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                interceptandoHorizontal = false;
                return false;
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        return super.onTouchEvent(ev);
    }
}
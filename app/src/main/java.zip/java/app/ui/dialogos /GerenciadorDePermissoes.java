package ui.dialogos;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

public class GerenciadorDePermissoes {

    public static final int CODIGO_REQUISICAO_ARMAZENAMENTO = 1001;

    // Verifica se a permissão de armazenamento já está liberada
    public static boolean temPermissaoArmazenamento(Activity atividade) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // Android 11+ exige checagem especial via Environment
            return Environment.isExternalStorageManager();
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // Android 6.0 até 10
            int resultadoLeitura = atividade.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE);
            int resultadoEscrita = atividade.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            return resultadoLeitura == PackageManager.PERMISSION_GRANTED 
                && resultadoEscrita == PackageManager.PERMISSION_GRANTED;
        }
        // Android 5.1 e inferiores (permissão concedida na instalação)
        return true;
    }

    // Solicita a permissão ao usuário
    public static void solicitarPermissaoArmazenamento(Activity atividade) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            // No Android 11+, precisamos redirecionar o usuário para a tela das configurações
            try {
                Intent intencao = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intencao.addCategory("android.intent.category.DEFAULT");
                intencao.setData(Uri.parse(String.format("package:%s", atividade.getPackageName())));
                atividade.startActivityForResult(intencao, CODIGO_REQUISICAO_ARMAZENAMENTO);
            } catch (Exception e) {
                Intent intencao = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                atividade.startActivityForResult(intencao, CODIGO_REQUISICAO_ARMAZENAMENTO);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            // Android 6.0 a 10 usam o diálogo nativo do sistema
            String[] permissoes = {
                Manifest.permission.READ_EXTERNAL_STORAGE,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            };
            atividade.requestPermissions(permissoes, CODIGO_REQUISICAO_ARMAZENAMENTO);
        }
    }
}
package ui.navegacao;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.util.Stack;

public class NavegadorTelas {

    public enum EstadoTela {
        TELA_INICIAL,
        TELA_SELETOR_PROJETO,
        TELA_ESTRUTURA_PROJETO,
        TELA_EDITOR
    }

    private final Activity atividade;
    private final FrameLayout conteinerPrincipal;
    private final Stack<EstadoTela> historicoNavegacao;

    private View viewHome;
    private View viewSeletor; // Adicionada a view do seletor
    private View viewEstrutura;
    private View viewEditor;

    public NavegadorTelas(Activity atividade) {
        this.atividade = atividade;
        this.conteinerPrincipal = new FrameLayout(atividade);
        this.conteinerPrincipal.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
        this.historicoNavegacao = new Stack<>();
    }

    public FrameLayout obterConteinerPrincipal() {
        return conteinerPrincipal;
    }

    // Método atualizado para receber as 4 views
    public void definirViewsTelas(View home, View seletor, View estrutura, View editor) {
        this.viewHome = home;
        this.viewSeletor = seletor;
        this.viewEstrutura = estrutura;
        this.viewEditor = editor;
    }

    public void navegarPara(EstadoTela novaTela) {
        if (!historicoNavegacao.isEmpty() && historicoNavegacao.peek() == novaTela) {
            return; // Já está na tela desejada
        }

        historicoNavegacao.push(novaTela);
        exibirTelaAtual();
    }

    public boolean voltarTelaAnterior() {
        if (historicoNavegacao.size() > 1) {
            historicoNavegacao.pop(); // Remove a tela atual
            exibirTelaAtual();
            return true; // Transição processada
        }
        return false; // Não há telas anteriores; pode fechar o app
    }

    private void exibirTelaAtual() {
        conteinerPrincipal.removeAllViews();
        EstadoTela telaAtual = historicoNavegacao.peek();

        switch (telaAtual) {
            case TELA_INICIAL:
                if (viewHome != null) conteinerPrincipal.addView(viewHome);
                break;
            case TELA_SELETOR_PROJETO:
                if (viewSeletor != null) conteinerPrincipal.addView(viewSeletor);
                break;
            case TELA_ESTRUTURA_PROJETO:
                if (viewEstrutura != null) conteinerPrincipal.addView(viewEstrutura);
                break;
            case TELA_EDITOR:
                if (viewEditor != null) conteinerPrincipal.addView(viewEditor);
                break;
        }
    }

    public EstadoTela obterTelaAtual() {
        return historicoNavegacao.isEmpty() ? EstadoTela.TELA_INICIAL : historicoNavegacao.peek();
    }
}
package ui.editor.sintaxe;

import android.content.Context;
import java.io.File;

public class FabricaDeSintaxe {

    private static GerenciadorSintaxeAssets gerenciador;

    public static void inicializar(Context contexto) {
        if (gerenciador == null) {
            gerenciador = new GerenciadorSintaxeAssets(contexto);
        }
    }

    public static SintaxeJson obterSintaxePorArquivo(File arquivo) {
        if (arquivo == null || gerenciador == null) return null;

        String nome = arquivo.getName();
        int pontoIndex = nome.lastIndexOf('.');
        if (pontoIndex == -1) return null;

        String extensao = nome.substring(pontoIndex + 1);
        return gerenciador.obterSintaxePorExtensao(extensao);
    }
}
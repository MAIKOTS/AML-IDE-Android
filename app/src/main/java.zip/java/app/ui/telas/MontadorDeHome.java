package ui.telas;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;

import app.R;

public class MontadorDeHome {

    public interface AcoesHome {
        void aoCliqueMenuHamburguer();
        void aoCliqueConfiguracoes();
        void aoCliqueCriarNovoProjeto();
        void aoCliqueImportarProjeto();
        void aoCliqueClonarGithub();
    }

    private final Context contexto;
    private final AcoesHome acoes;

    public MontadorDeHome(Context contexto, AcoesHome acoes) {
        this.contexto = contexto;
        this.acoes = acoes;
    }

    public View construirLayout() {
        // Infla a interface a partir do layout XML
        View layout = LayoutInflater.from(contexto).inflate(R.layout.comp_inicio, null, false);

        // Mapeia todos os elementos clicáveis como View genérica
        View btnHomeMenu = layout.findViewById(R.id.btn_home_menu);
        View btnHomeConfig = layout.findViewById(R.id.btn_home_config);
        View btnNovoProjeto = layout.findViewById(R.id.btn_novo_projeto);
        View btnAbrirProjeto = layout.findViewById(R.id.btn_abrir_projeto);
        View btnClonarGithub = layout.findViewById(R.id.btn_clonar_github);

        // Atribui a lógica de clique
        if (btnHomeMenu != null) {
            btnHomeMenu.setOnClickListener(v -> {
                if (acoes != null) acoes.aoCliqueMenuHamburguer();
            });
        }

        if (btnHomeConfig != null) {
            btnHomeConfig.setOnClickListener(v -> {
                if (acoes != null) acoes.aoCliqueConfiguracoes();
            });
        }

        if (btnNovoProjeto != null) {
            btnNovoProjeto.setOnClickListener(v -> {
                if (acoes != null) acoes.aoCliqueCriarNovoProjeto();
            });
        }

        if (btnAbrirProjeto != null) {
            btnAbrirProjeto.setOnClickListener(v -> {
                if (acoes != null) acoes.aoCliqueImportarProjeto();
            });
        }

        if (btnClonarGithub != null) {
            btnClonarGithub.setOnClickListener(v -> {
                if (acoes != null) acoes.aoCliqueClonarGithub();
            });
        }

        return layout;
    }
}
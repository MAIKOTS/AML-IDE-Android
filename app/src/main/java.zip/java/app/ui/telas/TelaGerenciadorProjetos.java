package ui.telas;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Arrays;

import app.R;
import ui.util.GerenciadorDeArquivos;

/**
 * Tela de gerenciamento de projetos.
 *
 * Fica fixa em /storage/emulated/0/AML_IDE/Projetos/
 *
 * Operações:
 *  - Criar novo projeto
 *  - Abrir projeto (click simples)
 *  - Renomear, copiar, recortar, colar, deletar (menu 3 pontinhos)
 */
public class TelaGerenciadorProjetos {

    public interface Acoes {
        void aoVoltar();
        void aoAbrirProjeto(File pasta);
    }

    // ==========================================================
    //  Clipboard ESTÁTICO (persiste entre aberturas da tela)
    // ==========================================================
    private static File clipboardArquivo = null;
    private static boolean clipboardEhRecorte = false;

    private final Context ctx;
    private final Acoes acoes;
    private final File pastaProjetos;

    private LinearLayout lista;
    private LinearLayout emptyState;
    private LinearLayout barraClipboard;
    private TextView clipboardTexto;
    private TextView caminhoTexto;

    public TelaGerenciadorProjetos(Context ctx, Acoes acoes) {
        this.ctx = ctx;
        this.acoes = acoes;
        this.pastaProjetos = new File(
                Environment.getExternalStorageDirectory(),
                "AML_IDE/Projetos");

        // Garante que a pasta existe
        if (!pastaProjetos.exists()) {
            pastaProjetos.mkdirs();
        }
    }

    // ==========================================================
    //  Construção
    // ==========================================================

    public View construir() {
        View raiz = LayoutInflater.from(ctx)
                .inflate(R.layout.tela_gerenciador_projetos, null, false);

        lista           = raiz.findViewById(R.id.projLista);
        emptyState      = raiz.findViewById(R.id.projEmptyState);
        barraClipboard  = raiz.findViewById(R.id.projBarraClipboard);
        clipboardTexto  = raiz.findViewById(R.id.projClipboardTexto);
        caminhoTexto    = raiz.findViewById(R.id.projCaminho);

        caminhoTexto.setText(pastaProjetos.getAbsolutePath());

        // Voltar
        raiz.findViewById(R.id.projBtnVoltar).setOnClickListener(v -> {
            if (acoes != null) acoes.aoVoltar();
        });

        // Novo projeto
        raiz.findViewById(R.id.projBtnNovo).setOnClickListener(v -> dialogoNovoProjeto());
        raiz.findViewById(R.id.projBtnCriarPrimeiro).setOnClickListener(v -> dialogoNovoProjeto());

        // Colar
        raiz.findViewById(R.id.projBtnColar).setOnClickListener(v -> colarClipboard());

        // Cancelar clipboard
        raiz.findViewById(R.id.projBtnCancelarClipboard).setOnClickListener(v -> {
            clipboardArquivo = null;
            clipboardEhRecorte = false;
            atualizarBarraClipboard();
        });

        atualizarBarraClipboard();
        recarregarLista();
        return raiz;
    }

    // ==========================================================
    //  Lista de projetos
    // ==========================================================

    private void recarregarLista() {
        lista.removeAllViews();

        File[] projetos = pastaProjetos.listFiles();
        if (projetos == null) projetos = new File[0];

        // Filtra só pastas e ignora ocultos
        java.util.List<File> validos = new java.util.ArrayList<>();
        for (File f : projetos) {
            if (f.isDirectory() && !f.getName().startsWith(".")) {
                validos.add(f);
            }
        }

        // Ordena alfabético
        validos.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));

        // Empty state
        if (validos.isEmpty()) {
            lista.setVisibility(View.GONE);
            emptyState.setVisibility(View.VISIBLE);
            return;
        }

        lista.setVisibility(View.VISIBLE);
        emptyState.setVisibility(View.GONE);

        LayoutInflater inflater = LayoutInflater.from(ctx);
        for (File projeto : validos) {
            lista.addView(criarItemProjeto(inflater, projeto));
        }
    }

    private View criarItemProjeto(LayoutInflater inflater, File projeto) {
        View item = inflater.inflate(R.layout.item_projeto, lista, false);

        TextView nome = item.findViewById(R.id.itemProjetoNome);
        TextView detalhe = item.findViewById(R.id.itemProjetoDetalhe);
        TextView menu = item.findViewById(R.id.itemProjetoMenu);

        nome.setText(projeto.getName());
        detalhe.setText(contarConteudo(projeto));

        // Click simples → abrir projeto
        item.setOnClickListener(v -> {
            if (acoes != null) acoes.aoAbrirProjeto(projeto);
        });

        // Long press → menu também
        item.setOnLongClickListener(v -> {
            menuContexto(projeto);
            return true;
        });

        // Click no ⋮ → menu
        menu.setOnClickListener(v -> menuContexto(projeto));

        return item;
    }

    private String contarConteudo(File pasta) {
        File[] filhos = pasta.listFiles();
        if (filhos == null || filhos.length == 0) return "vazio";

        int pastas = 0, arquivos = 0;
        for (File f : filhos) {
            if (f.getName().startsWith(".")) continue;
            if (f.isDirectory()) pastas++; else arquivos++;
        }

        if (pastas == 0 && arquivos == 0) return "vazio";
        StringBuilder sb = new StringBuilder();
        if (pastas > 0) sb.append(pastas).append(" pasta").append(pastas != 1 ? "s" : "");
        if (pastas > 0 && arquivos > 0) sb.append(", ");
        if (arquivos > 0) sb.append(arquivos).append(" arquivo").append(arquivos != 1 ? "s" : "");
        return sb.toString();
    }

    // ==========================================================
    //  Menu de contexto
    // ==========================================================

    private void menuContexto(File projeto) {
        String[] opcoes = {"✏  Renomear", "📋  Copiar", "✂  Recortar", "🗑  Deletar"};

        new AlertDialog.Builder(ctx)
                .setTitle(projeto.getName())
                .setItems(opcoes, (d, w) -> {
                    switch (w) {
                        case 0: dialogoRenomear(projeto); break;
                        case 1: copiarParaClipboard(projeto, false); break;
                        case 2: copiarParaClipboard(projeto, true); break;
                        case 3: confirmarDeletar(projeto); break;
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ==========================================================
    //  Novo projeto
    // ==========================================================

    private void dialogoNovoProjeto() {
        EditText campo = new EditText(ctx);
        campo.setHint("nome-do-projeto");
        campo.setPadding(dp(20), dp(20), dp(20), dp(20));
        campo.setSingleLine(true);

        new AlertDialog.Builder(ctx)
                .setTitle("Novo Projeto")
                .setMessage("Criar em: " + pastaProjetos.getAbsolutePath())
                .setView(campo)
                .setPositiveButton("Criar", (d, w) -> {
                    String nome = campo.getText().toString().trim();
                    if (nome.isEmpty()) return;

                    File novo = new File(pastaProjetos, nome);
                    if (novo.exists()) {
                        Toast.makeText(ctx, "Já existe um projeto com esse nome.",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (novo.mkdirs()) {
                        // Cria estrutura básica de projeto
                        new File(novo, "src").mkdirs();
                        new File(novo, "include").mkdirs();
                        new File(novo, "out").mkdirs();

                        Toast.makeText(ctx, "Projeto criado!", Toast.LENGTH_SHORT).show();
                        recarregarLista();
                    } else {
                        Toast.makeText(ctx, "Falha ao criar projeto.",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ==========================================================
    //  Renomear
    // ==========================================================

    private void dialogoRenomear(File projeto) {
        EditText campo = new EditText(ctx);
        campo.setText(projeto.getName());
        campo.setSelection(projeto.getName().length());
        campo.setPadding(dp(20), dp(20), dp(20), dp(20));
        campo.setSingleLine(true);

        new AlertDialog.Builder(ctx)
                .setTitle("Renomear")
                .setView(campo)
                .setPositiveButton("Renomear", (d, w) -> {
                    String novoNome = campo.getText().toString().trim();
                    if (novoNome.isEmpty() || novoNome.equals(projeto.getName())) return;

                    File novo = new File(projeto.getParentFile(), novoNome);
                    if (novo.exists()) {
                        Toast.makeText(ctx, "Já existe.", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    if (projeto.renameTo(novo)) {
                        Toast.makeText(ctx, "Renomeado.", Toast.LENGTH_SHORT).show();
                        recarregarLista();
                    } else {
                        Toast.makeText(ctx, "Falha ao renomear.",
                                Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    // ==========================================================
    //  Deletar
    // ==========================================================

    private void confirmarDeletar(File projeto) {
        new AlertDialog.Builder(ctx)
                .setTitle("Deletar projeto?")
                .setMessage("\"" + projeto.getName() + "\"\n\n" +
                        "Todos os arquivos dentro serão apagados permanentemente.")
                .setPositiveButton("Deletar", (d, w) -> {
                    boolean ok = deletarRecursivo(projeto);
                    Toast.makeText(ctx,
                            ok ? "Deletado." : "Falha ao deletar.",
                            Toast.LENGTH_SHORT).show();
                    recarregarLista();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private boolean deletarRecursivo(File f) {
        if (f == null || !f.exists()) return false;
        if (f.isDirectory()) {
            File[] filhos = f.listFiles();
            if (filhos != null) {
                for (File x : filhos) deletarRecursivo(x);
            }
        }
        return f.delete();
    }

    // ==========================================================
    //  Clipboard
    // ==========================================================

    private void copiarParaClipboard(File projeto, boolean recortar) {
        clipboardArquivo = projeto;
        clipboardEhRecorte = recortar;
        atualizarBarraClipboard();
        Toast.makeText(ctx,
                (recortar ? "Recortado: " : "Copiado: ") + projeto.getName(),
                Toast.LENGTH_SHORT).show();
    }

    private void atualizarBarraClipboard() {
        if (clipboardArquivo == null) {
            barraClipboard.setVisibility(View.GONE);
        } else {
            barraClipboard.setVisibility(View.VISIBLE);
            clipboardTexto.setText(
                    (clipboardEhRecorte ? "✂ " : "📋 ") + clipboardArquivo.getName());
        }
    }

    private void colarClipboard() {
        if (clipboardArquivo == null) return;

        // Destino: pasta de projetos com o mesmo nome
        File destino = new File(pastaProjetos, clipboardArquivo.getName());

        // Se já existe, adiciona sufixo
        if (destino.exists()) {
            String base = clipboardArquivo.getName();
            int i = 1;
            while (destino.exists()) {
                destino = new File(pastaProjetos, base + "_copia" + i);
                i++;
            }
        }

        boolean ok;
        if (clipboardEhRecorte) {
            ok = clipboardArquivo.renameTo(destino);
        } else {
            ok = copiarRecursivo(clipboardArquivo, destino);
        }

        if (ok) {
            Toast.makeText(ctx,
                    (clipboardEhRecorte ? "Movido: " : "Colado: ") + destino.getName(),
                    Toast.LENGTH_SHORT).show();
            clipboardArquivo = null;
            clipboardEhRecorte = false;
            atualizarBarraClipboard();
            recarregarLista();
        } else {
            Toast.makeText(ctx, "Falha na operação.", Toast.LENGTH_SHORT).show();
        }
    }

    private boolean copiarRecursivo(File origem, File destino) {
        try {
            if (origem.isDirectory()) {
                if (!destino.exists() && !destino.mkdirs()) return false;
                File[] filhos = origem.listFiles();
                if (filhos != null) {
                    for (File f : filhos) {
                        if (!copiarRecursivo(f, new File(destino, f.getName()))) return false;
                    }
                }
                return true;
            } else {
                return copiarArquivo(origem, destino);
            }
        } catch (Exception e) {
            return false;
        }
    }

    private boolean copiarArquivo(File origem, File destino) {
        try (InputStream in = new FileInputStream(origem);
             OutputStream out = new FileOutputStream(destino)) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    // ==========================================================
    //  Utils
    // ==========================================================

    private int dp(int v) {
        return (int) (v * ctx.getResources().getDisplayMetrics().density);
    }
}
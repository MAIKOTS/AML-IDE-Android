package ui.telas;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import app.R;
import ui.componentes.GutterView;
import ui.componentes.ScrollView2D;
import ui.editor.sintaxe.FabricaDeSintaxe;
import ui.editor.sintaxe.SintaxeJson;
import ui.util.CompiladorNative;
import ui.util.GerenciadorDeArquivos;

public class MontadorDeEditorComAbas {

    public interface AcoesEditor {
        void aoFecharEditor();
    }

    private final Context contexto;
    private final AcoesEditor acoesEditor;
    private final List<AbaArquivo> abasAbertas;
    private AbaArquivo abaAtiva;

    // Views do XML
    private LinearLayout conteinerAbas;
    private LinearLayout conteinerSimbolos;
    private EditText campoEditorCodigo;
    private ScrollView2D editorScroll2D;
    private TextView consoleDeSaida;
    private TextView textStatusAba;
    private GutterView editorGutter;

    private boolean estaFormatando = false;
    private boolean ignorarTrocaTexto = false;

    private final Handler handlerSintaxe = new Handler(Looper.getMainLooper());
    private Runnable runnableSintaxe;

    private static final String[] SIMBOLOS = {
            "{", "}", "(", ")", ";", "#", "<", ">",
            "\"", "'", "=", "+", "-", "*", "&", "|", "!"
    };

    public MontadorDeEditorComAbas(Context contexto, AcoesEditor acoesEditor) {
        this.contexto = contexto;
        this.acoesEditor = acoesEditor;
        this.abasAbertas = new ArrayList<>();
        FabricaDeSintaxe.inicializar(contexto);
    }

    // ==========================================================
    //  Construção
    // ==========================================================

    public View construirLayout() {
        View raiz = LayoutInflater.from(contexto)
                .inflate(R.layout.tela_editor, null, false);

        conteinerAbas     = raiz.findViewById(R.id.editorConteinerAbas);
        conteinerSimbolos = raiz.findViewById(R.id.editorConteinerSimbolos);
        campoEditorCodigo = raiz.findViewById(R.id.editorCampoCodigo);
        editorScroll2D    = raiz.findViewById(R.id.editorScroll2D);
        consoleDeSaida    = raiz.findViewById(R.id.editorConsole);
        textStatusAba     = raiz.findViewById(R.id.editorStatusAba);
        editorGutter      = raiz.findViewById(R.id.editorGutter);

        // Vincula gutter ↔ editor ↔ scrollView
        editorGutter.setEditor(campoEditorCodigo);
        editorGutter.setScrollView(editorScroll2D);

        raiz.findViewById(R.id.editorBtnVoltar).setOnClickListener(v -> {
            salvarArquivoAtual();
            if (acoesEditor != null) acoesEditor.aoFecharEditor();
        });
        raiz.findViewById(R.id.editorBtnSalvar).setOnClickListener(v -> salvarArquivoAtual());
        raiz.findViewById(R.id.editorBtnCompilar).setOnClickListener(v -> executarCompilacaoAtual());

        configurarMonitorDeTexto();
        popularSimbolos();

        return raiz;
    }

    // ==========================================================
    //  Símbolos rápidos
    // ==========================================================

    private void popularSimbolos() {
        conteinerSimbolos.removeAllViews();

        LayoutInflater inflater = LayoutInflater.from(contexto);

        for (String simbolo : SIMBOLOS) {
            TextView btn = (TextView) inflater.inflate(
                    R.layout.item_simbolo, conteinerSimbolos, false);
            btn.setText(simbolo);

            btn.setOnClickListener(v -> {
                if (campoEditorCodigo == null) return;
                int start = Math.max(campoEditorCodigo.getSelectionStart(), 0);
                int end = Math.max(campoEditorCodigo.getSelectionEnd(), 0);
                campoEditorCodigo.getText().replace(
                        Math.min(start, end), Math.max(start, end),
                        simbolo, 0, simbolo.length());
            });

            conteinerSimbolos.addView(btn);
        }
    }

    // ==========================================================
    //  Abas
    // ==========================================================

    private void atualizarVisualizacaoAbas() {
        conteinerAbas.removeAllViews();

        LayoutInflater inflater = LayoutInflater.from(contexto);

        for (AbaArquivo aba : abasAbertas) {
            boolean ehAtivo = aba.equals(abaAtiva);

            View itemAba = inflater.inflate(R.layout.item_aba, conteinerAbas, false);

            itemAba.setBackgroundResource(ehAtivo
                    ? R.drawable.bg_aba_editor_ativa
                    : R.drawable.bg_aba_editor);

            TextView titulo = itemAba.findViewById(R.id.abaTitulo);
            TextView fechar = itemAba.findViewById(R.id.abaBtnFechar);

            titulo.setText((aba.isModificado() ? "● " : "") + aba.getArquivo().getName());
            titulo.setTextColor(ehAtivo
                    ? Color.parseColor("#F4F4F5")
                    : Color.parseColor("#888888"));
            titulo.setTypeface(Typeface.MONOSPACE,
                    ehAtivo ? Typeface.BOLD : Typeface.NORMAL);

            itemAba.setOnClickListener(v -> selecionarAba(aba));
            fechar.setOnClickListener(v -> fecharAba(aba));

            conteinerAbas.addView(itemAba);
        }
    }

    private void fecharAba(AbaArquivo aba) {
        if (aba.isModificado()) {
            GerenciadorDeArquivos.salvarArquivo(aba.getArquivo(), aba.getConteudoEmMemoria());
        }

        abasAbertas.remove(aba);

        if (abaAtiva == aba) {
            if (!abasAbertas.isEmpty()) {
                selecionarAba(abasAbertas.get(abasAbertas.size() - 1));
            } else {
                abaAtiva = null;
                ignorarTrocaTexto = true;
                campoEditorCodigo.setText("");
                if (editorScroll2D != null) editorScroll2D.scrollTo(0, 0);
                ignorarTrocaTexto = false;
                textStatusAba.setText("Nenhum arquivo aberto");

                // ★ Zera o gutter
                if (editorGutter != null) {
                    editorGutter.requestLayout();
                    editorGutter.invalidate();
                }
            }
        }
        atualizarVisualizacaoAbas();
    }

    // ==========================================================
    //  Abrir / selecionar arquivo
    // ==========================================================

    public void abrirArquivo(File arquivo) {
        if (arquivo == null || !arquivo.exists()) return;

        AbaArquivo abaExistente = null;
        for (AbaArquivo aba : abasAbertas) {
            if (aba.getArquivo().getAbsolutePath().equals(arquivo.getAbsolutePath())) {
                abaExistente = aba;
                break;
            }
        }

        if (abaExistente == null) {
            String conteudo = GerenciadorDeArquivos.lerArquivo(arquivo);
            abaExistente = new AbaArquivo(arquivo, conteudo);
            abasAbertas.add(abaExistente);
        }

        selecionarAba(abaExistente);
    }

    private void selecionarAba(AbaArquivo aba) {
        this.abaAtiva = aba;

        ignorarTrocaTexto = true;
        campoEditorCodigo.setText(aba.getConteudoEmMemoria());
        ignorarTrocaTexto = false;

        // Reseta o scroll 2D e redesenha gutter após o layout
        campoEditorCodigo.post(() -> {
            if (editorScroll2D != null) {
                editorScroll2D.scrollTo(0, 0);
            }
            if (campoEditorCodigo != null) {
                campoEditorCodigo.invalidate();
            }
            // ★ Redesenha o gutter após trocar de aba
            if (editorGutter != null) {
                editorGutter.requestLayout();
                editorGutter.invalidate();
            }
        });

        if (campoEditorCodigo.getText() != null) {
            estaFormatando = true;
            aplicarSintaxeAtiva(campoEditorCodigo.getText());
            estaFormatando = false;
        }

        textStatusAba.setText((aba.isModificado() ? "* " : "") + aba.getArquivo().getName());
        atualizarVisualizacaoAbas();
    }

    // ==========================================================
    //  Salvar / Compilar
    // ==========================================================

    public void salvarArquivoAtual() {
        if (abaAtiva == null) return;

        boolean sucesso = GerenciadorDeArquivos.salvarArquivo(
                abaAtiva.getArquivo(), abaAtiva.getConteudoEmMemoria());

        if (sucesso) {
            abaAtiva.setModificado(false);
            textStatusAba.setText(abaAtiva.getArquivo().getName());
            atualizarVisualizacaoAbas();
            Toast.makeText(contexto, "Arquivo salvo com sucesso!",
                    Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(contexto, "Erro ao salvar o arquivo.",
                    Toast.LENGTH_SHORT).show();
        }
    }

    public void executarCompilacaoAtual() {
        if (abaAtiva == null) {
            Toast.makeText(contexto, "Nenhum arquivo aberto para compilar.",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        salvarArquivoAtual();
        consoleDeSaida.setTextColor(Color.parseColor("#29B6F6"));
        consoleDeSaida.setText("Iniciando compilação...\n");

        File arquivoFonte = abaAtiva.getArquivo();
        File pastaOut = new File(contexto.getFilesDir(), "out");
        pastaOut.mkdirs();

        String nomeBase = arquivoFonte.getName().replaceAll("\\.[^.]+$", "");
        File arquivoSaida = new File(pastaOut, "lib" + nomeBase + ".so");

        CompiladorNative.compilarParaSo(
                contexto,
                arquivoFonte,
                arquivoSaida,
                new CompiladorNative.ResultadoCompilacao() {
                    @Override
                    public void aoSucesso(File arquivoSo) {
                        new Handler(Looper.getMainLooper()).post(() -> {
                            consoleDeSaida.setTextColor(Color.parseColor("#00E676"));
                            consoleDeSaida.setText(
                                    "✓ Compilação concluída!\n" +
                                    "Arquivo: " + arquivoSo.getName() + "\n" +
                                    "Caminho: " + arquivoSo.getAbsolutePath() + "\n" +
                                    "Tamanho: " + arquivoSo.length() + " bytes\n");
                        });
                    }

                    @Override
                    public void aoErro(String mensagemErro) {
                        new Handler(Looper.getMainLooper()).post(() -> {
                            consoleDeSaida.setTextColor(Color.parseColor("#FF5252"));
                            consoleDeSaida.setText("✗ Falha na compilação:\n\n" + mensagemErro);
                        });
                    }
                });
    }

    // ==========================================================
    //  Monitor de texto + sintaxe
    // ==========================================================

    private void configurarMonitorDeTexto() {
        campoEditorCodigo.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable editable) {
                if (ignorarTrocaTexto || estaFormatando || abaAtiva == null) return;

                abaAtiva.setConteudoEmMemoria(editable.toString());
                if (!abaAtiva.isModificado()) {
                    abaAtiva.setModificado(true);
                    atualizarVisualizacaoAbas();
                }

                // Atualiza gutter (numeração pode ter mudado)
                if (editorGutter != null) {
                    editorGutter.post(() -> {
                        editorGutter.requestLayout();
                        editorGutter.invalidate();
                    });
                }

                // Invalida o editor
                campoEditorCodigo.invalidate();

                if (runnableSintaxe != null) {
                    handlerSintaxe.removeCallbacks(runnableSintaxe);
                }

                runnableSintaxe = () -> {
                    estaFormatando = true;
                    aplicarSintaxeAtiva(editable);
                    estaFormatando = false;
                    campoEditorCodigo.invalidate();
                    // ★ Redesenha o gutter após aplicar sintaxe (não muda nada, mas garante)
                    if (editorGutter != null) editorGutter.invalidate();
                };

                handlerSintaxe.postDelayed(runnableSintaxe, 300);
            }
        });
    }

    private void aplicarSintaxeAtiva(Editable editable) {
        if (abaAtiva == null) return;

        ForegroundColorSpan[] spansAntigos = editable.getSpans(
                0, editable.length(), ForegroundColorSpan.class);
        for (ForegroundColorSpan span : spansAntigos) {
            editable.removeSpan(span);
        }

        SintaxeJson sintaxe = FabricaDeSintaxe.obterSintaxePorArquivo(abaAtiva.getArquivo());
        if (sintaxe != null) {
            sintaxe.aplicarSintaxe(editable);
        }
    }

    public TextView obterConsoleDeSaida() { return consoleDeSaida; }
}
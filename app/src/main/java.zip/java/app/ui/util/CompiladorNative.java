package ui.util;

import android.content.Context;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public final class CompiladorNative {

    private static final String TAG = "CompiladorNative";

    private CompiladorNative() { }

    public interface ResultadoCompilacao {
        void aoSucesso(File arquivoSo);
        void aoErro(String mensagemErro);
    }

    public static void compilarParaSo(Context ctx,
                                      File arquivoCodigo,
                                      File arquivoSaidaSo,
                                      ResultadoCompilacao callback) {

        new Thread(() -> {
            try {
                if (arquivoCodigo == null || !arquivoCodigo.isFile()) {
                    callback.aoErro("Arquivo fonte não encontrado.");
                    return;
                }

                File clang = GerenciadorNDK.obterClang(ctx);
                if (clang == null || !clang.isFile()) {
                    callback.aoErro("Clang não encontrado.");
                    return;
                }

                File sysroot = GerenciadorNDK.obterSysroot(ctx);
                if (sysroot == null || !sysroot.isDirectory()) {
                    callback.aoErro("Sysroot não disponível.");
                    return;
                }

                File libsExtras = GerenciadorNDK.obterLibsExtras(ctx);

                File pai = arquivoSaidaSo.getParentFile();
                if (pai != null && !pai.exists()) pai.mkdirs();
                if (arquivoSaidaSo.exists()) arquivoSaidaSo.delete();

                String abi = GerenciadorNDK.obterAbi(ctx);
                String target;
                if (abi.contains("arm64")) {
                    target = "aarch64-linux-android21";
                } else if (abi.contains("armeabi")) {
                    target = "armv7a-linux-androideabi21";
                } else {
                    callback.aoErro("Arquitetura não suportada: " + abi);
                    return;
                }

                File sysrootUsr     = new File(sysroot, "usr");
                File sysrootInclude = new File(sysrootUsr, "include");
                File sysrootCxx     = new File(sysrootInclude, "c++/v1");
                File sysrootLib     = new File(sysrootUsr,
                        "lib/aarch64-linux-android/21");
                String nativeDir = ctx.getApplicationInfo().nativeLibraryDir;

                // Wrapper que re-executa o lld com argv[0]="ld.lld"
                File linker = new File(nativeDir, "libldwrapper.so");

                // Pasta com os runtimes do clang (headers internos + libs)
                File clangRuntime = null;
                if (libsExtras != null) {
                    File cr = new File(libsExtras, "clang-runtime");
                    if (cr.isDirectory()) clangRuntime = cr;
                }

                List<String> cmd = new ArrayList<>();
                cmd.add(clang.getAbsolutePath());
                cmd.add("-x"); cmd.add("c++");
                cmd.add("-shared");
                cmd.add("-fPIC");
                cmd.add("-O2");
                cmd.add("-std=c++17");

                cmd.add("-fuse-ld=" + linker.getAbsolutePath());

                cmd.add("--target=" + target);

                // ★ CRÍTICO: -resource-dir aponta para onde o clang
                // encontra seus headers internos (stddef.h, stdint.h, etc.)
                // e suas bibliotecas (libclang_rt.builtins, libunwind)
                if (clangRuntime != null) {
                    cmd.add("-resource-dir");
                    cmd.add(clangRuntime.getAbsolutePath());
                }

                // Sysroot
                cmd.add("-isysroot"); cmd.add(sysroot.getAbsolutePath());

                // -B para o sysroot (onde estão crtbegin_so.o e crtend_so.o)
                cmd.add("-B" + sysrootLib.getAbsolutePath());

                // Includes
                cmd.add("-I"); cmd.add(sysrootInclude.getAbsolutePath());
                cmd.add("-I"); cmd.add(sysrootCxx.getAbsolutePath());

                // Bibliotecas
                cmd.add("-L"); cmd.add(sysrootLib.getAbsolutePath());
                cmd.add("-L"); cmd.add(nativeDir);

                if (libsExtras != null) {
                    cmd.add("-L"); cmd.add(libsExtras.getAbsolutePath());
                }

                // -B e -L para o clang-runtime
                if (clangRuntime != null) {
                    cmd.add("-B" + clangRuntime.getAbsolutePath());
                    cmd.add("-L"); cmd.add(clangRuntime.getAbsolutePath());

                    // Adiciona também a pasta aarch64 (onde está libunwind.a)
                    File clangRuntimeAarch64 =
                            new File(clangRuntime, "lib/linux/aarch64");
                    if (clangRuntimeAarch64.isDirectory()) {
                        cmd.add("-L"); cmd.add(clangRuntimeAarch64.getAbsolutePath());
                    }

                    // E a pasta linux (onde está libclang_rt.builtins)
                    File clangRuntimeLinux =
                            new File(clangRuntime, "lib/linux");
                    if (clangRuntimeLinux.isDirectory()) {
                        cmd.add("-L"); cmd.add(clangRuntimeLinux.getAbsolutePath());
                    }
                }

                cmd.add("-o"); cmd.add(arquivoSaidaSo.getAbsolutePath());
                cmd.add(arquivoCodigo.getAbsolutePath());

                Log.i(TAG, "Comando: " + cmd);
                Log.i(TAG, "Linker: " + linker.getAbsolutePath());
                if (clangRuntime != null) {
                    Log.i(TAG, "Clang runtime: " + clangRuntime.getAbsolutePath());
                } else {
                    Log.w(TAG, "Clang runtime NÃO encontrado em libsExtras/clang-runtime");
                }

                ProcessBuilder pb = new ProcessBuilder(cmd);
                pb.redirectErrorStream(true);

                String pathAtual = pb.environment().get("PATH");
                pb.environment().put("PATH",
                        nativeDir + ":" + (pathAtual != null ? pathAtual : "/system/bin"));

                String ldPath = nativeDir;
                if (libsExtras != null) {
                    ldPath = libsExtras.getAbsolutePath() + ":" + ldPath;
                }
                pb.environment().put("LD_LIBRARY_PATH", ldPath);

                Log.i(TAG, "PATH=" + pb.environment().get("PATH"));
                Log.i(TAG, "LD_LIBRARY_PATH=" + ldPath);

                Process processo = pb.start();

                StringBuilder logs = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(processo.getInputStream()))) {
                    String linha;
                    while ((linha = reader.readLine()) != null) {
                        logs.append(linha).append("\n");
                    }
                }

                int codigoSaida = processo.waitFor();
                Log.i(TAG, "Exit code: " + codigoSaida);

                if (codigoSaida == 0 && arquivoSaidaSo.isFile()) {
                    callback.aoSucesso(arquivoSaidaSo);
                } else {
                    StringBuilder msg = new StringBuilder();
                    msg.append("Exit code: ").append(codigoSaida).append("\n");
                    if (logs.length() > 0) {
                        msg.append("\n--- saída do clang ---\n");
                        msg.append(logs);
                    } else {
                        msg.append("\n(clang não produziu saída)\n");
                    }
                    callback.aoErro(msg.toString());
                }

            } catch (Exception e) {
                Log.e(TAG, "Exceção ao compilar", e);
                callback.aoErro("Exceção: " + e.getMessage());
            }
        }, "compilador-native").start();
    }
}
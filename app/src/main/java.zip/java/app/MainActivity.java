package app;

import android.app.Activity;
import android.app.Dialog;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Toast;

import java.io.File;

import globalclass.settings.AppGlobalSettings;
import globalclass.util.PermissionFragment;
import modelo.GerenciadorDeProjetos;
import modelo.ManagerDiretoriosApp;
import ui.componentes.MenuLateralApp;
import ui.navegacao.NavegadorTelas;
import ui.telas.MontadorDeEditorComAbas;
import ui.telas.MontadorDeEstrutura;
import ui.telas.MontadorDeHome;
import ui.telas.MontadorDeSeletorDeProjetos;
import ui.telas.TelaClonarRepositorio;
import ui.telas.TelaComplementos;
import ui.telas.TelaExploradorFiles;
import ui.telas.TelaGerenciadorProjetos;

public class MainActivity extends Activity {

    private static final String TAG = "MainActivity";

    // Força o Android a extrair as libs para nativeLibraryDir/.
    // O Android extrai ANTES de tentar carregar, então mesmo que a
    // carga falhe (libs executáveis), o arquivo já está disponível.
    static {
        try { System.loadLibrary("c++_shared"); }
        catch (Throwable t) { Log.w(TAG, "c++_shared: " + t.getMessage()); }

        try { System.loadLibrary("ldreal"); }
        catch (Throwable t) { Log.w(TAG, "ldreal: " + t.getMessage()); }

        try { System.loadLibrary("ldwrapper"); }
        catch (Throwable t) { Log.w(TAG, "ldwrapper: " + t.getMessage()); }
    }

    private NavegadorTelas navegador;
    private GerenciadorDeProjetos gerenciadorProjetos;
    private MenuLateralApp painelComMenu;

    private MontadorDeHome montadorHome;
    private MontadorDeSeletorDeProjetos montadorSeletor;
    private MontadorDeEstrutura montadorEstrutura;
    private MontadorDeEditorComAbas montadorEditor;

    @Override
    protected void onCreate(Bundle estadoInstancia) {
        super.onCreate(estadoInstancia);

        AppGlobalSettings.aplicarModoFullScreen(this);
        AppGlobalSettings.inicializar(this);
        aplicarModoImersivo();

        solicitarPermissaoEInicializarDiretorios();

        gerenciadorProjetos = new GerenciadorDeProjetos();
        navegador = new NavegadorTelas(this);
        inicializarComponentesDeTela();

        painelComMenu = new MenuLateralApp(
                this,
                navegador.obterConteinerPrincipal(),
                navegador,
                new MenuLateralApp.AcoesMenu() {
                    @Override
                    public void aoNavegar(NavegadorTelas.EstadoTela tela) {
                        navegador.navegarPara(tela);
                        painelComMenu.fecharMenu();
                    }

                    @Override
                    public void aoAbrirComplementos() {
                        painelComMenu.fecharMenu();
                        abrirTelaComplementos();
                    }
                }
        );

        setContentView(painelComMenu);
        navegador.navegarPara(NavegadorTelas.EstadoTela.TELA_INICIAL);
    }

    // ============================================================
    //  BOOTSTRAP
    // ============================================================

    private void solicitarPermissaoEInicializarDiretorios() {
        PermissionFragment.solicitar(this, concedida -> {
            if (!concedida) {
                Toast.makeText(this,
                        "Sem permissão de armazenamento o app não pode criar projetos.",
                        Toast.LENGTH_LONG).show();
                return;
            }
        });
    }

    // ============================================================
    //  COMPLEMENTOS (tela cheia)
    // ============================================================

    /** Abre a tela de complementos em tela cheia. */
    private void abrirTelaComplementos() {
        final Dialog[] refDialog = new Dialog[1];

        TelaComplementos tela = new TelaComplementos(
                this,
                new TelaComplementos.Acoes() {
                    @Override
                    public void aoVoltar() {
                        if (refDialog[0] != null) refDialog[0].dismiss();
                    }

                    @Override
                    public void aoAbrirExploradorFiles() {
                        if (refDialog[0] != null) refDialog[0].dismiss();
                        abrirExploradorFiles();
                    }
                });

        View viewComplementos = tela.construir();

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(viewComplementos);
        dialog.setCancelable(true);
        dialog.show();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
        }

        refDialog[0] = dialog;
    }

    // ============================================================
    //  GERENCIADOR DE PROJETOS (tela cheia)
    // ============================================================

    /** Abre o gerenciador de projetos (pasta fixa em AML_IDE/Projetos). */
    private void abrirGerenciadorProjetos() {
        final Dialog[] refDialog = new Dialog[1];

        TelaGerenciadorProjetos tela = new TelaGerenciadorProjetos(
                this,
                new TelaGerenciadorProjetos.Acoes() {
                    @Override
                    public void aoVoltar() {
                        if (refDialog[0] != null) refDialog[0].dismiss();
                    }

                    @Override
                    public void aoAbrirProjeto(File pasta) {
                        if (refDialog[0] != null) refDialog[0].dismiss();

                        // Reusa a lógica do seletor: monta a estrutura e navega
                        View layoutEstruturaAtualizado =
                                montadorEstrutura.construirLayout(pasta, pasta.getName());

                        navegador.definirViewsTelas(
                                montadorHome.construirLayout(),
                                montadorSeletor.construirLayout(),
                                layoutEstruturaAtualizado,
                                montadorEditor.construirLayout()
                        );
                        navegador.navegarPara(NavegadorTelas.EstadoTela.TELA_ESTRUTURA_PROJETO);
                        Toast.makeText(MainActivity.this,
                                "Projeto aberto: " + pasta.getName(),
                                Toast.LENGTH_SHORT).show();
                    }
                });

        View view = tela.construir();

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(view);
        dialog.setCancelable(true);
        dialog.show();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
        }

        refDialog[0] = dialog;
    }

    // ============================================================
    //  CLONAR REPOSITÓRIO (tela cheia)
    // ============================================================

    /** Abre a tela de clonagem de repositório do GitHub. */
    private void abrirTelaClonarRepositorio() {
        final Dialog[] refDialog = new Dialog[1];

        TelaClonarRepositorio tela = new TelaClonarRepositorio(
                this,
                new TelaClonarRepositorio.Acoes() {
                    @Override
                    public void aoVoltar() {
                        if (refDialog[0] != null) refDialog[0].dismiss();
                    }

                    @Override
                    public void aoClonarComSucesso(File pastaProjeto) {
                        if (refDialog[0] != null) refDialog[0].dismiss();

                        // Abre o projeto recém-clonado na tela de estrutura
                        View layoutEstruturaAtualizado =
                                montadorEstrutura.construirLayout(pastaProjeto, pastaProjeto.getName());

                        navegador.definirViewsTelas(
                                montadorHome.construirLayout(),
                                montadorSeletor.construirLayout(),
                                layoutEstruturaAtualizado,
                                montadorEditor.construirLayout()
                        );
                        navegador.navegarPara(NavegadorTelas.EstadoTela.TELA_ESTRUTURA_PROJETO);
                        aplicarModoImersivo();
                        Toast.makeText(MainActivity.this,
                                "Repositório clonado: " + pastaProjeto.getName(),
                                Toast.LENGTH_LONG).show();
                    }
                });

        View view = tela.construir();

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(view);
        dialog.setCancelable(true);
        dialog.show();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
        }

        refDialog[0] = dialog;
    }

    // ============================================================
    //  EXPLORADOR DE ARQUIVOS (files/)
    // ============================================================

    /** Abre a tela de exploração da pasta files/ do app. */
    private void abrirExploradorFiles() {
        File pastaFiles = getFilesDir();

        final Dialog[] refDialog = new Dialog[1];

        TelaExploradorFiles tela = new TelaExploradorFiles(
                this,
                new TelaExploradorFiles.Acoes() {
                    @Override
                    public void aoVoltar() {
                        if (refDialog[0] != null) refDialog[0].dismiss();
                    }

                    @Override
                    public void aoRecarregar() {
                        // nada
                    }
                });

        View viewExplorador = tela.construir(pastaFiles);

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(viewExplorador);
        dialog.setCancelable(true);
        dialog.show();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setLayout(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT);
        }

        refDialog[0] = dialog;
    }

    // ============================================================
    //  UI
    // ============================================================

    private void inicializarComponentesDeTela() {
        montadorHome = new MontadorDeHome(this, new MontadorDeHome.AcoesHome() {
            @Override
            public void aoCliqueMenuHamburguer() {
                painelComMenu.abrirMenu();
            }

            @Override
            public void aoCliqueConfiguracoes() {
                aplicarModoImersivo();
            }

            @Override
            public void aoCliqueCriarNovoProjeto() {
                abrirGerenciadorProjetos();
            }

            @Override
            public void aoCliqueImportarProjeto() {
                navegador.navegarPara(NavegadorTelas.EstadoTela.TELA_SELETOR_PROJETO);
            }

            @Override
            public void aoCliqueClonarGithub() {
                // ★ Abre a tela de clonagem do GitHub
                abrirTelaClonarRepositorio();
            }
        });

        montadorSeletor = new MontadorDeSeletorDeProjetos(this, new MontadorDeSeletorDeProjetos.AcoesSeletor() {
            @Override
            public void aoSelecionarPastaProjeto(File pasta) {
                View layoutEstruturaAtualizado =
                        montadorEstrutura.construirLayout(pasta, pasta.getName());

                navegador.definirViewsTelas(
                        montadorHome.construirLayout(),
                        montadorSeletor.construirLayout(),
                        layoutEstruturaAtualizado,
                        montadorEditor.construirLayout()
                );
                navegador.navegarPara(NavegadorTelas.EstadoTela.TELA_ESTRUTURA_PROJETO);
                Toast.makeText(MainActivity.this,
                        "Projeto carregado: " + pasta.getName(),
                        Toast.LENGTH_SHORT).show();
            }

            @Override
            public void aoCancelar() {
                navegador.navegarPara(NavegadorTelas.EstadoTela.TELA_INICIAL);
            }
        });

        montadorEditor = new MontadorDeEditorComAbas(this, () -> {
            navegador.navegarPara(NavegadorTelas.EstadoTela.TELA_ESTRUTURA_PROJETO);
            aplicarModoImersivo();
        });

        montadorEstrutura = new MontadorDeEstrutura(this, new MontadorDeEstrutura.AcoesEstrutura() {
            @Override
            public void aoSelecionarArquivo(File arquivo) {
                montadorEditor.abrirArquivo(arquivo);
                navegador.navegarPara(NavegadorTelas.EstadoTela.TELA_EDITOR);
                aplicarModoImersivo();
            }

            @Override
            public void aoVoltar() {
                // Volta para a tela anterior na pilha; se não houver, vai para HOME
                if (!navegador.voltarTelaAnterior()) {
                    navegador.navegarPara(NavegadorTelas.EstadoTela.TELA_INICIAL);
                }
                aplicarModoImersivo();
            }
        });

        navegador.definirViewsTelas(
                montadorHome.construirLayout(),
                montadorSeletor.construirLayout(),
                montadorEstrutura.construirLayout(null, null),
                montadorEditor.construirLayout()
        );
    }

    // ============================================================
    //  CICLO DE VIDA
    // ============================================================

    @Override
    public void onBackPressed() {
        if (painelComMenu != null && painelComMenu.isMenuAberto()) {
            painelComMenu.fecharMenu();
            aplicarModoImersivo();
            return;
        }

        if (!navegador.voltarTelaAnterior()) {
            super.onBackPressed();
        } else {
            aplicarModoImersivo();
        }
    }

    @Override
    public void onWindowFocusChanged(boolean temFoco) {
        super.onWindowFocusChanged(temFoco);
        if (temFoco) {
            aplicarModoImersivo();
        }
    }

    private void aplicarModoImersivo() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }
}
package globalclass.util;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.Settings;

@SuppressWarnings("deprecation")
public class PermissionFragment extends Fragment {

    private static final String TAG = "PermissionFragmentTag";
    private static final int CODIGO_REQUISICAO_PERMISSAO = 1001;
    private static final int CODIGO_REQUISICAO_GERENCIAR_STORAGE = 1002;

    public interface CallbackPermissao {
        void onResultado(boolean concedida);
    }

    private CallbackPermissao callback;

    public PermissionFragment() {}

    public static void solicitar(Activity activity, CallbackPermissao callback) {
        if (temPermissao(activity)) {
            if (callback != null) callback.onResultado(true);
            return;
        }

        FragmentManager fm = activity.getFragmentManager();
        PermissionFragment fragment = (PermissionFragment) fm.findFragmentByTag(TAG);

        if (fragment == null) {
            fragment = new PermissionFragment();
            fragment.callback = callback;
            fm.beginTransaction().add(fragment, TAG).commitAllowingStateLoss();
        } else {
            fragment.callback = callback;
        }
    }

    public static boolean temPermissao(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return Environment.isExternalStorageManager();
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            int leitura = activity.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE);
            int escrita = activity.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            return leitura == PackageManager.PERMISSION_GRANTED && escrita == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRetainInstance(true);
        
        // Exibe o Pop-up de explicação antes de mandar para a tela do sistema
        exibirDialogoExplicativo();
    }

    private void exibirDialogoExplicativo() {
        Activity activity = getActivity();
        if (activity == null) return;

        new AlertDialog.Builder(activity)
                .setTitle("Permissão de Armazenamento")
                .setMessage("A AML IDE precisa de acesso ao armazenamento para criar, salvar e ler as pastas dos seus projetos de modding no dispositivo.")
                .setCancelable(false)
                .setPositiveButton("Continuar", (dialog, which) -> {
                    iniciarSolicitacao();
                })
                .setNegativeButton("Cancelar", (dialog, which) -> {
                    notificarERemover(false);
                })
                .show();
    }

    private void iniciarSolicitacao() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(Uri.parse("package:" + getActivity().getPackageName()));
                startActivityForResult(intent, CODIGO_REQUISICAO_GERENCIAR_STORAGE);
            } catch (Exception e) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                startActivityForResult(intent, CODIGO_REQUISICAO_GERENCIAR_STORAGE);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            requestPermissions(
                    new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                    },
                    CODIGO_REQUISICAO_PERMISSAO
            );
        } else {
            notificarERemover(true);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CODIGO_REQUISICAO_PERMISSAO) {
            boolean ok = temPermissao(getActivity());
            notificarERemover(ok);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CODIGO_REQUISICAO_GERENCIAR_STORAGE) {
            boolean ok = temPermissao(getActivity());
            notificarERemover(ok);
        }
    }

    private void notificarERemover(boolean concedida) {
        if (callback != null) {
            callback.onResultado(concedida);
        }
        if (getFragmentManager() != null) {
            getFragmentManager().beginTransaction().remove(this).commitAllowingStateLoss();
        }
    }
}
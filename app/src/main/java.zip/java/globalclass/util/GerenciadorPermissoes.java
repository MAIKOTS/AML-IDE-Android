package globalclass.util;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

public final class GerenciadorPermissoes {

    public static final int CODIGO_REQUISICAO_PERMISSAO = 1001;
    public static final int CODIGO_REQUISICAO_GERENCIAR_STORAGE = 1002;

    private GerenciadorPermissoes() {}

    // Interface para notificar a MainActivity sobre a decisão do usuário
    public interface CallbackPermissao {
        void onResultadoPermissao(boolean concedida);
    }

    /**
     * Método único para verificar e solicitar permissão de forma limpa.
     */
    public static void verificarESolicitar(Activity activity, CallbackPermissao callback) {
        if (temPermissaoArmazenamento(activity)) {
            if (callback != null) {
                callback.onResultadoPermissao(true);
            }
        } else {
            solicitarPermissaoArmazenamento(activity);
        }
    }

    /**
     * Repassa o tratamento dos resultados dos callbacks nativos da Activity.
     */
    public static void tratarResultado(Activity activity, int requestCode, CallbackPermissao callback) {
        boolean concedida = temPermissaoArmazenamento(activity);
        if (callback != null) {
            callback.onResultadoPermissao(concedida);
        }
    }

    public static boolean temPermissaoArmazenamento(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            return Environment.isExternalStorageManager();
        } else {
            int leitura = activity.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE);
            int escrita = activity.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
            return leitura == PackageManager.PERMISSION_GRANTED && escrita == PackageManager.PERMISSION_GRANTED;
        }
    }

    private static void solicitarPermissaoArmazenamento(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                intent.setData(Uri.parse("package:" + activity.getPackageName()));
                activity.startActivityForResult(intent, CODIGO_REQUISICAO_GERENCIAR_STORAGE);
            } catch (Exception e) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                activity.startActivityForResult(intent, CODIGO_REQUISICAO_GERENCIAR_STORAGE);
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            activity.requestPermissions(
                    new String[]{
                            Manifest.permission.READ_EXTERNAL_STORAGE,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                    },
                    CODIGO_REQUISICAO_PERMISSAO
            );
        }
    }
}
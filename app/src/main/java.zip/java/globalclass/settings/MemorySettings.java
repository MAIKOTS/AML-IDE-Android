package globalclass.settings;

import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.res.Configuration;

public class MemorySettings {

    private static ComponentCallbacks2 activeCallback;

    public static void registrarMonitorDeMemoria(Context context, Runnable callbackLiberarMemoria) {
        if (context == null) return;

        Context appContext = context.getApplicationContext();

        activeCallback = new ComponentCallbacks2() {
            @Override
            public void onTrimMemory(int level) {
                // Alerta de pressão de memória média a alta
                if (level >= TRIM_MEMORY_MODERATE) {
                    if (callbackLiberarMemoria != null) {
                        callbackLiberarMemoria.run();
                    }
                }
            }

            @Override
            public void onConfigurationChanged(Configuration newConfig) {}

            @Override
            public void onLowMemory() {
                // Alerta crítico de memória baixa
                if (callbackLiberarMemoria != null) {
                    callbackLiberarMemoria.run();
                }
            }
        };

        appContext.registerComponentCallbacks(activeCallback);
    }

    public static void removerMonitorDeMemoria(Context context) {
        if (context == null || activeCallback == null) return;
        
        context.getApplicationContext().unregisterComponentCallbacks(activeCallback);
        activeCallback = null;
    }
}
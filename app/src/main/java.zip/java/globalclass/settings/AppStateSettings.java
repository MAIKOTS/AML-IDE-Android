package globalclass.settings;

import android.content.Context;
import android.content.SharedPreferences;

public class AppStateSettings {

    private static final String PREF_NAME = "mkide_state";
    private static final String KEY_CODIGO = "ultimo_codigo";
    private static final String KEY_CURSOR_POS = "posicao_cursor";
    private static final String KEY_CAMINHO_ARQUIVO = "caminho_arquivo_aberto";
    private static final String KEY_TELA_ATUAL = "tela_atual";

    private static SharedPreferences getPrefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static void salvarEstadoCompleto(Context context, String codigo, int posicaoCursor, String caminhoArquivo, String telaAtual) {
        if (context == null) return;

        getPrefs(context).edit()
                .putString(KEY_CODIGO, codigo)
                .putInt(KEY_CURSOR_POS, posicaoCursor)
                .putString(KEY_CAMINHO_ARQUIVO, caminhoArquivo)
                .putString(KEY_TELA_ATUAL, telaAtual)
                .apply();
    }

    public static void salvarEstado(Context context, String codigo, int posicaoCursor) {
        if (context == null) return;

        getPrefs(context).edit()
                .putString(KEY_CODIGO, codigo)
                .putInt(KEY_CURSOR_POS, posicaoCursor)
                .apply();
    }

    public static String obterCodigoSalvo(Context context) {
        if (context == null) return "";
        return getPrefs(context).getString(KEY_CODIGO, "");
    }

    public static int obterPosicaoCursorSalva(Context context) {
        if (context == null) return 0;
        return getPrefs(context).getInt(KEY_CURSOR_POS, 0);
    }

    public static String obterCaminhoArquivoSalvo(Context context) {
        if (context == null) return null;
        return getPrefs(context).getString(KEY_CAMINHO_ARQUIVO, null);
    }

    public static String obterTelaAtualSalva(Context context) {
        if (context == null) return null;
        return getPrefs(context).getString(KEY_TELA_ATUAL, null);
    }

    public static void limparEstado(Context context) {
        if (context == null) return;
        getPrefs(context).edit().clear().apply();
    }
}